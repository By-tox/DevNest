import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";

export default function Home() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [activePage, setActivePage] = useState("browse");
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    tags: "",
    content: "",
  });
  const [profile, setProfile] = useState({ name: user?.name || "المستخدم", bio: "", github: "" });

  // Fetch scripts
  const { data: scripts = [] } = trpc.scripts.list.useQuery({});
  const publishMutation = trpc.scripts.create.useMutation();
  const downloadMutation = trpc.scripts.download.useMutation();

  useEffect(() => {
    const saved = localStorage.getItem("devnest_profile");
    if (saved) setProfile(JSON.parse(saved));
  }, []);

  const handlePublish = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await publishMutation.mutateAsync({
        title: formData.title,
        description: formData.description,
        tags: formData.tags,
        content: formData.content,
      });
      setFormData({ title: "", description: "", tags: "", content: "" });
      setActivePage("browse");
    } catch (error) {
      console.error("Failed to publish:", error);
    }
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    const newProfile = {
      name: (document.getElementById("editName") as HTMLInputElement)?.value || "المستخدم",
      bio: (document.getElementById("editBio") as HTMLInputElement)?.value || "",
      github: (document.getElementById("editGithub") as HTMLInputElement)?.value || "",
    };
    setProfile(newProfile);
    localStorage.setItem("devnest_profile", JSON.stringify(newProfile));
  };

  const filteredScripts = scripts.filter(
    (s: any) =>
      s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (s.description?.toLowerCase() || "").includes(searchQuery.toLowerCase())
  );

  return (
    <div style={{ minHeight: "100vh", background: "#000", color: "#fff", display: "flex", flexDirection: "column" }}>
      {/* Header */}
      <header style={{ padding: "18px", borderBottom: "1px solid #1a1a1a", background: "rgba(0,0,0,0.78)" }}>
        <div style={{ maxWidth: "1200px", margin: "0 auto", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
            <h1 style={{ fontSize: "1.1rem" }}>🔥 DevNest</h1>
            <p style={{ color: "#999", fontSize: "0.85rem" }}>منصة نشر ومشاركة السكربتات</p>
          </div>
          <nav style={{ display: "flex", gap: "10px" }}>
            <button
              onClick={() => setActivePage("browse")}
              style={{
                background: "none",
                border: "none",
                color: activePage === "browse" ? "#ff6b35" : "#999",
                cursor: "pointer",
                fontWeight: "700",
                borderBottom: activePage === "browse" ? "2px solid #ff6b35" : "none",
                padding: "8px 10px",
              }}
            >
              استكشف
            </button>
            <button
              onClick={() => setActivePage("publish")}
              style={{
                background: "none",
                border: "none",
                color: activePage === "publish" ? "#ff6b35" : "#999",
                cursor: "pointer",
                fontWeight: "700",
                borderBottom: activePage === "publish" ? "2px solid #ff6b35" : "none",
                padding: "8px 10px",
              }}
            >
              نشر
            </button>
            <button
              onClick={() => setActivePage("profile")}
              style={{
                background: "none",
                border: "none",
                color: activePage === "profile" ? "#ff6b35" : "#999",
                cursor: "pointer",
                fontWeight: "700",
                borderBottom: activePage === "profile" ? "2px solid #ff6b35" : "none",
                padding: "8px 10px",
              }}
            >
              ملفي
            </button>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main style={{ maxWidth: "1200px", margin: "22px auto", padding: "0 18px", width: "100%", flex: "1" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 360px", gap: "18px" }}>
          {/* Left Column */}
          <Card style={{ background: "rgba(26,26,26,0.9)", border: "1px solid #1a1a1a", borderRadius: "10px", padding: "16px" }}>
            {activePage === "browse" && (
              <>
                <div style={{ display: "flex", gap: "8px", marginBottom: "12px" }}>
                  <Input
                    placeholder="ابحث بالعنوان أو الوصف..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    style={{ flex: "1", padding: "10px", borderRadius: "8px", background: "#0a0a0a", border: "1px solid #1a1a1a", color: "#fff" }}
                  />
                  <Button style={{ padding: "10px 14px", background: "#ff6b35", color: "#000", fontWeight: "700" }}>بحث</Button>
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "14px" }}>
                  {filteredScripts.length === 0 ? (
                    <div style={{ textAlign: "center", padding: "40px", color: "#999", gridColumn: "1 / -1" }}>
                      <p>لا توجد سكربتات حالياً</p>
                    </div>
                  ) : (
                    filteredScripts.map((script: any) => (
                      <div
                        key={script.id}
                        style={{
                          background: "rgba(26,26,26,0.9)",
                          border: "1px solid #1a1a1a",
                          borderRadius: "10px",
                          padding: "12px",
                          display: "flex",
                          flexDirection: "column",
                          gap: "8px",
                        }}
                      >
                        <div style={{ display: "flex", gap: "10px", alignItems: "center", padding: "8px", borderRadius: "8px", background: "rgba(255,107,53,0.04)" }}>
                          <div
                            style={{
                              width: "44px",
                              height: "44px",
                              borderRadius: "50%",
                              background: "#ff6b35",
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "center",
                              color: "#000",
                              fontWeight: "800",
                            }}
                          >
                            {script.userId?.toString().charAt(0) || "U"}
                          </div>
                          <div style={{ flex: "1", textAlign: "right" }}>
                            <strong>المستخدم #{script.userId}</strong>
                            <br />
                            <span style={{ color: "#999", fontSize: "0.9rem" }}>مطور سكربتات</span>
                          </div>
                        </div>

                        <h3 style={{ margin: "0", fontSize: "1rem" }}>{script.title}</h3>
                        <p style={{ color: "#999", fontSize: "0.9rem", margin: "0" }}>{script.description || "بدون وصف"}</p>

                        {script.tags && (
                          <div style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}>
                            {script.tags.split(",").map((tag: string, idx: number) => (
                              <span key={idx} style={{ background: "#111", padding: "6px 8px", borderRadius: "6px", color: "#999", fontSize: "0.82rem" }}>
                                {tag.trim()}
                              </span>
                            ))}
                          </div>
                        )}

                        <div style={{ color: "#999", fontSize: "0.9rem", display: "flex", gap: "10px" }}>
                          <span>👁️ {script.views || 0}</span>
                          <span>⬇️ {script.downloads || 0}</span>
                        </div>

                        <div style={{ display: "flex", gap: "8px" }}>
                          <Button
                            onClick={() => downloadMutation.mutate({ id: script.id })}
                            style={{ flex: "1", padding: "8px 10px", background: "#ff6b35", color: "#000", fontWeight: "700" }}
                          >
                            ⬇️ تحميل
                          </Button>
                          <Button
                            onClick={() => navigator.clipboard.writeText(script.content)}
                            style={{ flex: "1", padding: "8px 10px", background: "#0a0a0a", color: "#fff", fontWeight: "700" }}
                          >
                            📋 نسخ
                          </Button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </>
            )}
          </Card>

          {/* Right Column */}
          <Card style={{ background: "rgba(26,26,26,0.9)", border: "1px solid #1a1a1a", borderRadius: "10px", padding: "16px", height: "fit-content" }}>
            {activePage === "browse" && (
              <div>
                <h3>المميزات</h3>
                <p style={{ color: "#999", fontSize: "0.9rem", marginBottom: "12px" }}>عرض سريع للسكربتات، اسم الناشر يظهر مع علامة التوثيق</p>
                <Button style={{ width: "100%", padding: "10px", background: "#ff6b35", color: "#000", fontWeight: "700" }}>تحديث العرض</Button>
              </div>
            )}

            {activePage === "publish" && (
              <div>
                <h3>نشر سكربت</h3>
                <form onSubmit={handlePublish} style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                  <div>
                    <label>العنوان *</label>
                    <Input
                      required
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      style={{ width: "100%", padding: "10px", borderRadius: "8px", background: "#0a0a0a", border: "1px solid #1a1a1a", color: "#fff" }}
                    />
                  </div>
                  <div>
                    <label>الوصف</label>
                    <Input
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      style={{ width: "100%", padding: "10px", borderRadius: "8px", background: "#0a0a0a", border: "1px solid #1a1a1a", color: "#fff" }}
                    />
                  </div>
                  <div>
                    <label>الوسوم</label>
                    <Input
                      value={formData.tags}
                      onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                      placeholder="مثال: roblox, exploit, lua"
                      style={{ width: "100%", padding: "10px", borderRadius: "8px", background: "#0a0a0a", border: "1px solid #1a1a1a", color: "#fff" }}
                    />
                  </div>
                  <div>
                    <label>محتوى السكربت *</label>
                    <textarea
                      required
                      value={formData.content}
                      onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                      placeholder="ضع الكود هنا"
                      style={{ width: "100%", padding: "10px", borderRadius: "8px", background: "#0a0a0a", border: "1px solid #1a1a1a", color: "#fff", minHeight: "160px", fontFamily: "'Courier New', monospace" }}
                    />
                  </div>
                  <div style={{ display: "flex", gap: "8px" }}>
                    <Button type="submit" style={{ flex: "1", padding: "10px", background: "#ff6b35", color: "#000", fontWeight: "700" }}>
                      نشر
                    </Button>
                    <Button
                      type="button"
                      onClick={() => setFormData({ title: "", description: "", tags: "", content: "" })}
                      style={{ flex: "1", padding: "10px", background: "#0a0a0a", color: "#fff", fontWeight: "700" }}
                    >
                      مسح
                    </Button>
                  </div>
                </form>
              </div>
            )}

            {activePage === "profile" && (
              <div>
                <h3>ملفي</h3>
                <div style={{ textAlign: "center", marginBottom: "16px" }}>
                  <div
                    style={{
                      width: "88px",
                      height: "88px",
                      borderRadius: "50%",
                      background: "#ff6b35",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      color: "#000",
                      fontWeight: "800",
                      fontSize: "34px",
                      margin: "0 auto 8px",
                    }}
                  >
                    {profile.name.charAt(0).toUpperCase()}
                  </div>
                  <div style={{ fontWeight: "800", fontSize: "1.05rem" }}>{profile.name}</div>
                  {profile.github && <div style={{ background: "rgba(76,175,80,0.12)", color: "#4caf50", padding: "2px 6px", borderRadius: "6px", marginTop: "6px", display: "inline-block" }}>موثق</div>}
                </div>

                <form onSubmit={handleSaveProfile} style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                  <div>
                    <label>اسم المستخدم</label>
                    <Input
                      id="editName"
                      defaultValue={profile.name}
                      style={{ width: "100%", padding: "10px", borderRadius: "8px", background: "#0a0a0a", border: "1px solid #1a1a1a", color: "#fff" }}
                    />
                  </div>
                  <div>
                    <label>نبذة قصيرة</label>
                    <Input
                      id="editBio"
                      defaultValue={profile.bio}
                      style={{ width: "100%", padding: "10px", borderRadius: "8px", background: "#0a0a0a", border: "1px solid #1a1a1a", color: "#fff" }}
                    />
                  </div>
                  <div>
                    <label>رابط GitHub</label>
                    <Input
                      id="editGithub"
                      type="url"
                      defaultValue={profile.github}
                      placeholder="https://github.com/username"
                      style={{ width: "100%", padding: "10px", borderRadius: "8px", background: "#0a0a0a", border: "1px solid #1a1a1a", color: "#fff" }}
                    />
                  </div>
                  <div style={{ display: "flex", gap: "8px" }}>
                    <Button type="submit" style={{ flex: "1", padding: "10px", background: "#ff6b35", color: "#000", fontWeight: "700" }}>
                      حفظ
                    </Button>
                    <Button type="button" style={{ flex: "1", padding: "10px", background: "#0a0a0a", color: "#fff", fontWeight: "700" }}>
                      تسجيل خروج
                    </Button>
                  </div>
                </form>
              </div>
            )}
          </Card>
        </div>
      </main>

      {/* Footer */}
      <footer style={{ padding: "14px", borderTop: "1px solid #1a1a1a", textAlign: "center", color: "#999" }}>
        © 2025 DevNest — جميع الحقوق محفوظة
      </footer>
    </div>
  );
}
