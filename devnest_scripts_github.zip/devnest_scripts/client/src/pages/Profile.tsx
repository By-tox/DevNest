import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { APP_LOGO, APP_TITLE, getLoginUrl } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";
import { Github, Check, LogOut } from "lucide-react";

export default function Profile() {
  const { isAuthenticated, user, logout } = useAuth();
  const [, setLocation] = useLocation();

  const [githubUsername, setGithubUsername] = useState("");
  const [githubUrl, setGithubUrl] = useState("");
  const [showGithubForm, setShowGithubForm] = useState(false);

  const { data: userScripts = [] } = trpc.scripts.byUser.useQuery(
    { userId: user?.id || 0, limit: 20 },
    { enabled: !!user?.id }
  );

  const { data: githubProfile } = trpc.github.getProfile.useQuery(
    { userId: user?.id || 0 },
    { enabled: !!user?.id }
  );

  const linkGithubMutation = trpc.github.linkProfile.useMutation({
    onSuccess: () => {
      toast.success("تم ربط حساب GitHub بنجاح!");
      setGithubUsername("");
      setGithubUrl("");
      setShowGithubForm(false);
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ أثناء ربط حساب GitHub");
    },
  });

  const handleLinkGithub = (e: React.FormEvent) => {
    e.preventDefault();
    if (!githubUsername.trim() || !githubUrl.trim()) {
      toast.error("يرجى ملء جميع الحقول");
      return;
    }
    linkGithubMutation.mutate({
      githubUsername,
      githubUrl,
    });
  };

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex flex-col bg-background text-foreground">
        <header className="border-b border-border bg-background/80 backdrop-blur-sm">
          <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
            <Link href="/" className="flex items-center gap-3">
              <img src={APP_LOGO} alt="DevNest" className="w-12 h-12" />
              <div>
                <h1 className="text-xl font-bold">{APP_TITLE}</h1>
                <p className="text-sm text-muted">منصة نشر السكربتات والنصوص</p>
              </div>
            </Link>
          </div>
        </header>

        <main className="flex-1 flex items-center justify-center px-4">
          <div className="bg-card border border-border rounded-lg p-8 text-center max-w-md">
            <h2 className="text-2xl font-bold mb-4">يرجى تسجيل الدخول</h2>
            <p className="text-muted mb-6">
              تحتاج إلى تسجيل الدخول لعرض ملفك الشخصي
            </p>
            <a href={getLoginUrl()}>
              <Button className="w-full bg-accent text-accent-foreground">
                تسجيل الدخول
              </Button>
            </a>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-border bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3 hover:opacity-80 transition">
            <img src={APP_LOGO} alt="DevNest" className="w-12 h-12" />
            <div>
              <h1 className="text-xl font-bold">{APP_TITLE}</h1>
              <p className="text-sm text-muted">منصة نشر السكربتات والنصوص</p>
            </div>
          </Link>
          <nav className="flex items-center gap-6">
            <Link href="/" className="text-muted hover:text-foreground transition">
              الرئيسية
            </Link>
            <Link href="/scripts" className="text-muted hover:text-foreground transition">
              السكربتات
            </Link>
            <Link href="/publish" className="text-muted hover:text-foreground transition">
              نشر سكربت
            </Link>
            <Link href="/profile" className="text-accent font-bold">
              الملف الشخصي
            </Link>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLogout}
              className="text-muted hover:text-foreground"
            >
              <LogOut className="w-4 h-4" />
            </Button>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-6xl mx-auto px-4 py-12 w-full">
        {/* Profile Header */}
        <div className="bg-card border border-border rounded-lg p-8 mb-8">
          <div className="flex items-start justify-between mb-6">
            <div>
              <h2 className="text-3xl font-bold mb-2">{user?.name || "المستخدم"}</h2>
              <p className="text-muted">{user?.email}</p>
            </div>
            <div className="text-right">
              {githubProfile?.isVerified ? (
                <div className="flex items-center gap-2 text-accent">
                  <Check className="w-5 h-5" />
                  <span className="font-bold">موثق</span>
                </div>
              ) : (
                <span className="text-muted">غير موثق</span>
              )}
            </div>
          </div>

          {/* GitHub Profile Section */}
          <div className="border-t border-border pt-6">
            <h3 className="font-bold mb-4 flex items-center gap-2">
              <Github className="w-5 h-5" />
              حساب GitHub
            </h3>

            {githubProfile ? (
              <div className="bg-background rounded-lg p-4 mb-4">
                <p className="mb-2">
                  <strong>اسم المستخدم:</strong> {githubProfile.githubUsername}
                </p>
                <a
                  href={githubProfile.githubUrl || "#"}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-accent hover:underline"
                >
                  {githubProfile.githubUrl}
                </a>
              </div>
            ) : (
              <p className="text-muted mb-4">لم تربط حساب GitHub بعد</p>
            )}

            {!showGithubForm ? (
              <Button
                variant="outline"
                onClick={() => setShowGithubForm(true)}
              >
                {githubProfile ? "تحديث حساب GitHub" : "ربط حساب GitHub"}
              </Button>
            ) : (
              <form onSubmit={handleLinkGithub} className="space-y-4">
                <div>
                  <label className="block text-sm font-bold mb-2">اسم مستخدم GitHub</label>
                  <Input
                    type="text"
                    placeholder="مثال: your-username"
                    value={githubUsername || ""}
                    onChange={(e) => setGithubUsername(e.target.value)}
                    className="bg-background border-border"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold mb-2">رابط GitHub</label>
                  <Input
                    type="url"
                    placeholder="https://github.com/your-username"
                    value={githubUrl || ""}
                    onChange={(e) => setGithubUrl(e.target.value)}
                    className="bg-background border-border"
                    required
                  />
                </div>
                <div className="flex gap-2">
                  <Button
                    type="submit"
                    className="bg-accent text-accent-foreground"
                    disabled={linkGithubMutation.isPending}
                  >
                    {linkGithubMutation.isPending ? "جاري الربط..." : "ربط"}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowGithubForm(false)}
                  >
                    إلغاء
                  </Button>
                </div>
              </form>
            )}
          </div>
        </div>

        {/* User Scripts */}
        <div className="bg-card border border-border rounded-lg p-8">
          <h3 className="text-2xl font-bold mb-6">سكربتاتك</h3>

          {userScripts.length > 0 ? (
            <div className="space-y-4">
              {userScripts.map((script) => (
                <div key={script.id} className="border border-border rounded-lg p-4 hover:border-accent transition">
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-bold">{script.title}</h4>
                    <span className="bg-accent/20 text-accent text-xs px-2 py-1 rounded">
                      {script.language}
                    </span>
                  </div>
                  <p className="text-muted text-sm mb-2">
                    {script.description || "بدون وصف"}
                  </p>
                  <div className="flex gap-4 text-xs text-muted">
                    <span>👁️ {script.views || 0} مشاهدة</span>
                    <span>⬇️ {script.downloads || 0} تحميل</span>
                    <span>📅 {new Date(script.createdAt).toLocaleDateString("ar-SA")}</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-muted mb-4">لم تنشر أي سكربتات بعد</p>
              <Link href="/publish">
                <Button className="bg-accent text-accent-foreground">
                  نشر سكربتك الأول
                </Button>
              </Link>
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-background/50 py-6 mt-12">
        <div className="max-w-6xl mx-auto px-4 text-center text-muted text-sm">
          <p>© 2025 DevNest — جميع الحقوق محفوظة</p>
        </div>
      </footer>
    </div>
  );
}
