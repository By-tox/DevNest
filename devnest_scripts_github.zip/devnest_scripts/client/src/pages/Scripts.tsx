import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { APP_LOGO, APP_TITLE, getLoginUrl } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import { Search, Download, Copy, Github, Eye, Check } from "lucide-react";

export default function Scripts() {
  const { isAuthenticated } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [offset, setOffset] = useState(0);
  const limit = 12;

  const { data: scripts = [] } = trpc.scripts.list.useQuery({ limit, offset });
  const { data: searchResults = [] } = trpc.scripts.search.useQuery(
    { query: searchQuery, limit, offset },
    { enabled: searchQuery.length > 0 }
  );

  const downloadMutation = trpc.scripts.download.useMutation();
  const githubProfiles = trpc.github.getProfile.useQuery({ userId: 0 }, { enabled: false });

  const displayScripts = searchQuery ? searchResults : scripts;

  const handleDownload = (scriptId: number, title: string) => {
    downloadMutation.mutate({ id: scriptId });
    const script = displayScripts.find(s => s.id === scriptId);
    if (script) {
      const element = document.createElement("a");
      element.setAttribute("href", "data:text/plain;charset=utf-8," + encodeURIComponent(script.content));
      element.setAttribute("download", `${title}.txt`);
      element.style.display = "none";
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    }
  };

  const handleCopy = (content: string) => {
    navigator.clipboard.writeText(content);
    alert("تم نسخ النص إلى الحافظة!");
  };

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-border bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3 hover:opacity-80 transition">
            <img src={APP_LOGO} alt="DevNest" className="w-12 h-12" />
            <div>
              <h1 className="text-xl font-bold">{APP_TITLE}</h1>
              <p className="text-sm text-muted">منصة نشر السكربتات والنصوص</p>
            </div>
          </Link>
          <nav className="flex items-center gap-6">
            <Link href="/" className="text-muted hover:text-foreground transition">
              الرئيسية
            </Link>
            <Link href="/scripts" className="text-accent font-bold">
              السكربتات
            </Link>
            <Link href="/publish" className="text-muted hover:text-foreground transition">
              نشر سكربت
            </Link>
            {isAuthenticated ? (
              <Link href="/profile" className="text-muted hover:text-foreground transition">
                الملف الشخصي
              </Link>
            ) : (
              <a href={getLoginUrl()} className="text-muted hover:text-foreground transition">
                تسجيل الدخول
              </a>
            )}
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-6xl mx-auto px-4 py-12 w-full">
        {/* Search Bar */}
        <div className="mb-8">
          <div className="relative">
            <Search className="absolute right-4 top-3 w-5 h-5 text-muted" />
            <Input
              type="text"
              placeholder="ابحث عن سكربتات..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setOffset(0);
              }}
              className="pr-12 bg-card border-border"
            />
          </div>
        </div>

        {/* Scripts Grid */}
        {displayScripts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {displayScripts.map((script) => (
              <div key={script.id} className="bg-card border border-border rounded-lg p-6 hover:border-accent transition">
                <div className="flex items-start justify-between mb-3">
                  <h3 className="font-bold text-lg flex-1">{script.title}</h3>
                  <span className="bg-accent/20 text-accent text-xs px-2 py-1 rounded">
                    {script.language}
                  </span>
                </div>

                <p className="text-muted text-sm mb-4 line-clamp-2">
                  {script.description || "بدون وصف"}
                </p>

                {script.tags && (
                  <div className="flex flex-wrap gap-2 mb-4">
                    {script.tags.split(",").map((tag, i) => (
                      <span key={i} className="bg-muted/10 text-muted text-xs px-2 py-1 rounded">
                        #{tag.trim()}
                      </span>
                    ))}
                  </div>
                )}

                <div className="flex items-center gap-4 text-xs text-muted mb-4 pb-4 border-b border-border">
                  <div className="flex items-center gap-1">
                    <Eye className="w-3 h-3" />
                    <span>{script.views || 0}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Download className="w-3 h-3" />
                    <span>{script.downloads || 0}</span>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleDownload(script.id, script.title)}
                    className="flex-1"
                  >
                    <Download className="w-4 h-4" />
                    تحميل
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleCopy(script.content)}
                    className="flex-1"
                  >
                    <Copy className="w-4 h-4" />
                    نسخ
                  </Button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-muted mb-4">لا توجد سكربتات</p>
            {isAuthenticated && (
              <Link href="/publish">
                <Button className="bg-accent text-accent-foreground">
                  ابدأ بنشر سكربتك الأول
                </Button>
              </Link>
            )}
          </div>
        )}

        {/* Pagination */}
        {displayScripts.length >= limit && (
          <div className="flex justify-center gap-4 mt-8">
            <Button
              variant="outline"
              onClick={() => setOffset(Math.max(0, offset - limit))}
              disabled={offset === 0}
            >
              السابق
            </Button>
            <Button
              variant="outline"
              onClick={() => setOffset(offset + limit)}
            >
              التالي
            </Button>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-background/50 py-6 mt-12">
        <div className="max-w-6xl mx-auto px-4 text-center text-muted text-sm">
          <p>© 2025 DevNest — جميع الحقوق محفوظة</p>
        </div>
      </footer>
    </div>
  );
}
