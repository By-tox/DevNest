import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { APP_LOGO, APP_TITLE, getLoginUrl } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";

export default function Publish() {
  const { isAuthenticated, user } = useAuth();
  const [, setLocation] = useLocation();

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [content, setContent] = useState("");
  const [language, setLanguage] = useState("lua");
  const [tags, setTags] = useState("");

  const createMutation = trpc.scripts.create.useMutation({
    onSuccess: () => {
      toast.success("تم نشر السكربت بنجاح!");
      setTitle("");
      setDescription("");
      setContent("");
      setLanguage("lua");
      setTags("");
      setLocation("/scripts");
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ أثناء نشر السكربت");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) {
      toast.error("يرجى ملء العنوان والمحتوى");
      return;
    }
    createMutation.mutate({
      title,
      description,
      content,
      language,
      tags,
    });
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex flex-col bg-background text-foreground">
        <header className="border-b border-border bg-background/80 backdrop-blur-sm">
          <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
            <Link href="/" className="flex items-center gap-3">
              <img src={APP_LOGO} alt="DevNest" className="w-12 h-12" />
              <div>
                <h1 className="text-xl font-bold">{APP_TITLE}</h1>
                <p className="text-sm text-muted">منصة نشر السكربتات والنصوص</p>
              </div>
            </Link>
          </div>
        </header>

        <main className="flex-1 flex items-center justify-center px-4">
          <div className="bg-card border border-border rounded-lg p-8 text-center max-w-md">
            <h2 className="text-2xl font-bold mb-4">يرجى تسجيل الدخول</h2>
            <p className="text-muted mb-6">
              تحتاج إلى تسجيل الدخول لنشر سكربت جديد
            </p>
            <a href={getLoginUrl()}>
              <Button className="w-full bg-accent text-accent-foreground">
                تسجيل الدخول
              </Button>
            </a>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-border bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3 hover:opacity-80 transition">
            <img src={APP_LOGO} alt="DevNest" className="w-12 h-12" />
            <div>
              <h1 className="text-xl font-bold">{APP_TITLE}</h1>
              <p className="text-sm text-muted">منصة نشر السكربتات والنصوص</p>
            </div>
          </Link>
          <nav className="flex items-center gap-6">
            <Link href="/" className="text-muted hover:text-foreground transition">
              الرئيسية
            </Link>
            <Link href="/scripts" className="text-muted hover:text-foreground transition">
              السكربتات
            </Link>
            <Link href="/publish" className="text-accent font-bold">
              نشر سكربت
            </Link>
            <Link href="/profile" className="text-muted hover:text-foreground transition">
              الملف الشخصي
            </Link>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-2xl mx-auto px-4 py-12 w-full">
        <div className="bg-card border border-border rounded-lg p-8">
          <h2 className="text-3xl font-bold mb-2">نشر سكربت جديد</h2>
          <p className="text-muted mb-8">شارك سكربتك مع المجتمع</p>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Title */}
            <div>
              <label className="block text-sm font-bold mb-2">العنوان *</label>
              <Input
                type="text"
                placeholder="أدخل عنوان السكربت"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="bg-background border-border"
                required
              />
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm font-bold mb-2">الوصف</label>
              <Textarea
                placeholder="أضف وصفاً للسكربت (اختياري)"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="bg-background border-border min-h-24"
              />
            </div>

            {/* Language */}
            <div>
              <label className="block text-sm font-bold mb-2">لغة البرمجة</label>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="w-full bg-background border border-border rounded-md px-3 py-2 text-foreground"
              >
                <option value="lua">Lua</option>
                <option value="javascript">JavaScript</option>
                <option value="python">Python</option>
                <option value="other">أخرى</option>
              </select>
            </div>

            {/* Tags */}
            <div>
              <label className="block text-sm font-bold mb-2">الوسوم (مفصولة بفواصل)</label>
              <Input
                type="text"
                placeholder="مثال: roblox, exploit, lua"
                value={tags}
                onChange={(e) => setTags(e.target.value)}
                className="bg-background border-border"
              />
            </div>

            {/* Content */}
            <div>
              <label className="block text-sm font-bold mb-2">محتوى السكربت *</label>
              <Textarea
                placeholder="أدخل كود السكربت هنا"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="bg-background border-border min-h-64 font-mono text-sm"
                required
              />
              <p className="text-xs text-muted mt-2">
                {content.length} حرف
              </p>
            </div>

            {/* Submit */}
            <div className="flex gap-3">
              <Button
                type="submit"
                className="flex-1 bg-accent text-accent-foreground"
                disabled={createMutation.isPending}
              >
                {createMutation.isPending ? "جاري النشر..." : "نشر السكربت"}
              </Button>
              <Link href="/scripts">
                <Button type="button" variant="outline" className="flex-1">
                  إلغاء
                </Button>
              </Link>
            </div>
          </form>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-background/50 py-6 mt-12">
        <div className="max-w-6xl mx-auto px-4 text-center text-muted text-sm">
          <p>© 2025 DevNest — جميع الحقوق محفوظة</p>
        </div>
      </footer>
    </div>
  );
}
