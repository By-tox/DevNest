import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { APP_LOGO, APP_TITLE } from "@/const";
import { toast } from "sonner";
import { Search, Download, Copy, Plus, X } from "lucide-react";

export default function ScriptsHub() {
  const [view, setView] = useState<"browse" | "publish">("browse");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTags, setSelectedTags] = useState<string[]>([]);

  // Form states
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [content, setContent] = useState("");
  const [tags, setTags] = useState("");

  // Fetch scripts
  const { data: allScripts = [] } = trpc.scripts.list.useQuery({ limit: 1000, offset: 0 });

  // Create mutation
  const createMutation = trpc.scripts.create.useMutation({
    onSuccess: () => {
      toast.success("تم نشر السكربت بنجاح!");
      setTitle("");
      setDescription("");
      setContent("");
      setTags("");
      setView("browse");
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ أثناء نشر السكربت");
    },
  });

  // Download mutation
  const downloadMutation = trpc.scripts.download.useMutation();

  // Filter scripts
  const filteredScripts = useMemo(() => {
    return allScripts.filter((script) => {
      const matchesSearch =
        script.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        script.description?.toLowerCase().includes(searchQuery.toLowerCase());

      if (selectedTags.length === 0) return matchesSearch;

      const scriptTags = script.tags?.split(",").map((t) => t.trim().toLowerCase()) || [];
      const hasMatchingTag = selectedTags.some((tag) =>
        scriptTags.includes(tag.toLowerCase())
      );

      return matchesSearch && hasMatchingTag;
    });
  }, [allScripts, searchQuery, selectedTags]);

  // Get all unique tags
  const allTags = useMemo(() => {
    const tagSet = new Set<string>();
    allScripts.forEach((script) => {
      script.tags?.split(",").forEach((tag) => {
        tagSet.add(tag.trim());
      });
    });
    return Array.from(tagSet).sort();
  }, [allScripts]);

  const handlePublish = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) {
      toast.error("يرجى ملء العنوان والمحتوى");
      return;
    }
    createMutation.mutate({
      title,
      description,
      content,
      language: "lua",
      tags,
    });
  };

  const handleDownload = (script: typeof allScripts[0]) => {
    downloadMutation.mutate({ id: script.id });
    const element = document.createElement("a");
    element.setAttribute(
      "href",
      "data:text/plain;charset=utf-8," + encodeURIComponent(script.content)
    );
    element.setAttribute("download", `${script.title}.txt`);
    element.style.display = "none";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleCopy = (content: string) => {
    navigator.clipboard.writeText(content);
    toast.success("تم نسخ النص إلى الحافظة!");
  };

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-border bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={APP_LOGO} alt="DevNest" className="w-12 h-12" />
            <div>
              <h1 className="text-xl font-bold">{APP_TITLE}</h1>
              <p className="text-sm text-muted">منصة نشر والبحث عن السكربتات</p>
            </div>
          </div>

          <div className="flex gap-2">
            <Button
              variant={view === "browse" ? "default" : "outline"}
              onClick={() => setView("browse")}
              className="gap-2"
            >
              <Search className="w-4 h-4" />
              استكشف
            </Button>
            <Button
              variant={view === "publish" ? "default" : "outline"}
              onClick={() => setView("publish")}
              className="gap-2"
            >
              <Plus className="w-4 h-4" />
              نشر
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-6xl mx-auto px-4 py-8 w-full">
        {view === "browse" ? (
          <>
            {/* Search Bar */}
            <div className="mb-8">
              <div className="relative mb-6">
                <Search className="absolute right-4 top-3 w-5 h-5 text-muted" />
                <Input
                  type="text"
                  placeholder="ابحث عن سكربتات..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pr-12 bg-card border-border text-lg"
                />
              </div>

              {/* Tags Filter */}
              {allTags.length > 0 && (
                <div className="bg-card border border-border rounded-lg p-4">
                  <p className="text-sm font-bold mb-3">الفلترة حسب الوسوم:</p>
                  <div className="flex flex-wrap gap-2">
                    {allTags.map((tag) => (
                      <button
                        key={tag}
                        onClick={() => toggleTag(tag)}
                        className={`px-3 py-1 rounded-full text-sm font-medium transition ${
                          selectedTags.includes(tag)
                            ? "bg-accent text-accent-foreground"
                            : "bg-border text-muted hover:bg-muted/20"
                        }`}
                      >
                        #{tag}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Scripts Grid */}
            {filteredScripts.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredScripts.map((script) => (
                  <div
                    key={script.id}
                    className="bg-card border border-border rounded-lg p-6 hover:border-accent transition flex flex-col"
                  >
                    <div className="flex-1">
                      <h3 className="font-bold text-lg mb-2 line-clamp-2">
                        {script.title}
                      </h3>

                      <p className="text-muted text-sm mb-4 line-clamp-3">
                        {script.description || "بدون وصف"}
                      </p>

                      {script.tags && (
                        <div className="flex flex-wrap gap-1 mb-4">
                          {script.tags.split(",").map((tag, i) => (
                            <button
                              key={i}
                              onClick={() => toggleTag(tag.trim())}
                              className="bg-muted/10 hover:bg-muted/20 text-muted text-xs px-2 py-1 rounded transition"
                            >
                              #{tag.trim()}
                            </button>
                          ))}
                        </div>
                      )}

                      <div className="flex items-center gap-4 text-xs text-muted py-3 border-t border-border">
                        <div className="flex items-center gap-1">
                          👁️ <span>{script.views || 0}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          ⬇️ <span>{script.downloads || 0}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex gap-2 pt-4">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDownload(script)}
                        className="flex-1 gap-1"
                      >
                        <Download className="w-4 h-4" />
                        تحميل
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleCopy(script.content)}
                        className="flex-1 gap-1"
                      >
                        <Copy className="w-4 h-4" />
                        نسخ
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-card border border-border rounded-lg">
                <p className="text-muted text-lg">لا توجد سكربتات</p>
                <p className="text-muted text-sm mt-2">كن أول من ينشر سكربت!</p>
              </div>
            )}
          </>
        ) : (
          <>
            {/* Publish Form */}
            <div className="max-w-2xl mx-auto">
              <div className="bg-card border border-border rounded-lg p-8">
                <h2 className="text-3xl font-bold mb-2">نشر سكربت جديد</h2>
                <p className="text-muted mb-8">شارك سكربتك مع المجتمع</p>

                <form onSubmit={handlePublish} className="space-y-6">
                  {/* Title */}
                  <div>
                    <label className="block text-sm font-bold mb-2">
                      العنوان *
                    </label>
                    <Input
                      type="text"
                      placeholder="أدخل عنوان السكربت"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      className="bg-background border-border"
                      required
                    />
                  </div>

                  {/* Description */}
                  <div>
                    <label className="block text-sm font-bold mb-2">
                      الوصف
                    </label>
                    <Textarea
                      placeholder="أضف وصفاً للسكربت (اختياري)"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className="bg-background border-border min-h-24"
                    />
                  </div>

                  {/* Tags */}
                  <div>
                    <label className="block text-sm font-bold mb-2">
                      الوسوم (مفصولة بفواصل)
                    </label>
                    <Input
                      type="text"
                      placeholder="مثال: roblox, exploit, lua"
                      value={tags}
                      onChange={(e) => setTags(e.target.value)}
                      className="bg-background border-border"
                    />
                  </div>

                  {/* Content */}
                  <div>
                    <label className="block text-sm font-bold mb-2">
                      محتوى السكربت *
                    </label>
                    <Textarea
                      placeholder="أدخل كود السكربت هنا"
                      value={content}
                      onChange={(e) => setContent(e.target.value)}
                      className="bg-background border-border min-h-64 font-mono text-sm"
                      required
                    />
                    <p className="text-xs text-muted mt-2">
                      {content.length} حرف
                    </p>
                  </div>

                  {/* Submit */}
                  <div className="flex gap-3">
                    <Button
                      type="submit"
                      className="flex-1 bg-accent text-accent-foreground"
                      disabled={createMutation.isPending}
                    >
                      {createMutation.isPending ? "جاري النشر..." : "نشر السكربت"}
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      className="flex-1"
                      onClick={() => setView("browse")}
                    >
                      إلغاء
                    </Button>
                  </div>
                </form>
              </div>
            </div>
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-background/50 py-6 mt-12">
        <div className="max-w-6xl mx-auto px-4 text-center text-muted text-sm">
          <p>© 2025 DevNest — جميع الحقوق محفوظة</p>
          <p className="mt-2">منصة عصرية لنشر ومشاركة السكربتات</p>
        </div>
      </footer>
    </div>
  );
}
