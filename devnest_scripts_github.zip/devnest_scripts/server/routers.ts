import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  scripts: router({
    list: publicProcedure
      .input(z.object({
        limit: z.number().default(20),
        offset: z.number().default(0),
      }))
      .query(async ({ input }) => {
        return await db.getAllScripts(input.limit, input.offset);
      }),

    search: publicProcedure
      .input(z.object({
        query: z.string(),
        limit: z.number().default(20),
        offset: z.number().default(0),
      }))
      .query(async ({ input }) => {
        return await db.searchScripts(input.query, input.limit, input.offset);
      }),

    getById: publicProcedure
      .input(z.object({
        id: z.number(),
      }))
      .query(async ({ input }) => {
        const script = await db.getScriptById(input.id);
        if (script) {
          await db.updateScriptViews(input.id);
        }
        return script;
      }),

    byUser: publicProcedure
      .input(z.object({
        userId: z.number(),
        limit: z.number().default(20),
        offset: z.number().default(0),
      }))
      .query(async ({ input }) => {
        return await db.getScriptsByUserId(input.userId, input.limit, input.offset);
      }),

    create: protectedProcedure
      .input(z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        content: z.string().min(1),
        language: z.string().default("lua"),
        tags: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const script = await db.createScript({
          userId: ctx.user.id,
          title: input.title,
          description: input.description,
          content: input.content,
          language: input.language,
          tags: input.tags,
        });
        return script;
      }),

    download: publicProcedure
      .input(z.object({
        id: z.number(),
      }))
      .mutation(async ({ input }) => {
        await db.updateScriptDownloads(input.id);
        const script = await db.getScriptById(input.id);
        return script;
      }),
  }),

  github: router({
    getProfile: publicProcedure
      .input(z.object({
        userId: z.number(),
      }))
      .query(async ({ input }) => {
        return await db.getGitHubProfile(input.userId);
      }),

    linkProfile: protectedProcedure
      .input(z.object({
        githubUsername: z.string().min(1),
        githubUrl: z.string().url(),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.createOrUpdateGitHubProfile(
          ctx.user.id,
          input.githubUsername,
          input.githubUrl,
          true
        );
      }),
  }),
});

export type AppRouter = typeof appRouter;
