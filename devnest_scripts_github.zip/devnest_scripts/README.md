# DevNest Scripts - منصة نشر ومشاركة السكربتات

منصة عربية لنشر ومشاركة السكربتات والأكواد مع نظام بحث وفلترة متقدم.

## الميزات

✅ نشر السكربتات بسهولة
✅ البحث والفلترة حسب الوسوم
✅ ملفات شخصية للمستخدمين
✅ توثيق حساب GitHub
✅ تحميل ونسخ السكربتات
✅ إحصائيات المشاهدات والتحميلات

## المتطلبات

- Node.js 18+
- pnpm
- MySQL 8+

## التثبيت

```bash
# 1. استنساخ المشروع
git clone https://github.com/yourusername/devnest_scripts.git
cd devnest_scripts

# 2. تثبيت المكتبات
pnpm install

# 3. إعداد قاعدة البيانات
pnpm db:push

# 4. تشغيل الخادم
pnpm dev
```

## هيكل المشروع

```
devnest_scripts/
├── client/              # الواجهة الأمامية (React)
│   ├── src/
│   │   ├── pages/      # الصفحات
│   │   ├── components/ # المكونات
│   │   └── App.tsx     # التطبيق الرئيسي
│   └── index.html
├── server/              # الخادم (Express + tRPC)
│   ├── routers.ts      # API الرئيسي
│   └── db.ts           # دوال قاعدة البيانات
├── drizzle/             # قاعدة البيانات
│   └── schema.ts       # هيكل الجداول
└── package.json
```

## متغيرات البيئة

أنشئ ملف `.env` بالمتغيرات التالية:

```
DATABASE_URL=mysql://user:password@localhost:3306/devnest
JWT_SECRET=your-secret-key
VITE_APP_TITLE=DevNest Scripts
```

## التطوير

```bash
# تشغيل خادم التطوير
pnpm dev

# بناء المشروع
pnpm build

# تشغيل الإنتاج
pnpm start
```

## النشر على GitHub

```bash
# إضافة الملفات
git add .

# إنشاء commit
git commit -m "Initial commit: DevNest Scripts"

# رفع المشروع
git push origin main
```

## الترخيص

MIT License

## المساهمة

نرحب بالمساهمات! يرجى فتح Issue أو Pull Request.
